#include<bits/stdc++.h>
using namespace std;
int main(){
    string s="Scissor";
    int key;
    cin >> key;
    string temp;
    for(int i=0;i<100;i++){
        cout<<s<<endl;
        cin >> temp;
    }
}